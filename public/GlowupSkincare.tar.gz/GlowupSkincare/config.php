<?php
// Konfigurasi dasar aplikasi
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'glowupskincare');

define('APP_NAME', 'GlowupSkincare');
define('BASE_URL', 'http://localhost/GlowupSkincare');
define('UPLOAD_DIR', __DIR__ . '/uploads');
define('UPLOAD_URL', BASE_URL . '/uploads');
?>
